package com.seleniumLearning.maven;

import org.testng.annotations.Test;

public class SeleniumTest {

	@Test
	public void BrowserAutomation()
	{
		System.out.println("BrowserAutomation");
	}
	
	
	@Test 
	public void elementsUI ()
	{
		System.out.println("elementsUI");
	}
	
	
	@Test 
	public void LoginTest ()
	{
		System.out.println("LoginTest");
	}
	
	
}
