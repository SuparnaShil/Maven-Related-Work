package com.seleniumLearning.maven;

import org.testng.annotations.Test;

public class AppiumTest {  
	    
	@Test 
	public void NativeAppAndroid()
	{ 
		System.out.println("NativeAppAndroid");
	} 
	
	
	@Test
	public void IOSApp()
	{		
		System.out.println("IOSApp");
	}

}
