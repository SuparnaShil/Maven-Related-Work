package com.seleniumLearning.maven;

import org.testng.annotations.Test;

public class RESTAPITest {
	
	@Test
	public void PostJIRA()
	{
		System.out.println("PostJIRA");
	}
	
	@Test
	public void DeleteTwitter()
	{
		System.out.println("DeleteTwitter");
	}

	
}
